from logging import getLogger
import voluptuous as vol
from typing import Any
from homeassistant.config_entries import (
    ConfigEntry,
    ConfigFlow,
    OptionsFlowWithConfigEntry,
    OptionsFlow,
)
from .const import (
    DOMAIN,
    DEFAULT_NAME,
    CONF_MIN_ALTITUDE,
    CONF_MAX_ALTITUDE,
    CONF_ENABLE_TRACKER,
    CONF_AUTO_CLEANUP,
    CONF_ENABLE_TRACKER_DEFAULT,
    CONF_AUTO_CLEANUP_DEFAULT,
    MIN_ALTITUDE,
    MAX_ALTITUDE,
    CONF_TRACKER_NAME_STYLE,
    CONF_TRACKER_NAME_DEFAULT,
    TRACKER_NAME_CALLSIGN,
    TRACKER_NAME_CALLSIGN_ROUTE,
    TRACKER_NAME_REG_ROUTE,
)
from FlightRadarAPI import FlightRadar24API
import homeassistant.helpers.config_validation as cv
from homeassistant.data_entry_flow import FlowResult
from homeassistant.core import callback
from homeassistant.const import (
    CONF_LATITUDE,
    CONF_LONGITUDE,
    CONF_RADIUS,
    CONF_SCAN_INTERVAL,
    CONF_PASSWORD,
    CONF_USERNAME,
)

_LOGGER = getLogger(__name__)


def _http_status_code(error: Exception) -> int | None:
    code = getattr(error, "status_code", None)
    if code is not None:
        return int(code)
    response = getattr(error, "response", None)
    if response is not None:
        code = getattr(response, "status_code", None)
        if code is not None:
            return int(code)
    return None


def _is_login_rate_limited(error: Exception) -> bool:
    if _http_status_code(error) == 429:
        return True
    message = str(error)
    return "429" in message


def _is_login_auth_error(error: Exception) -> bool:
    return _http_status_code(error) in (401, 403)


class FlightRadarConfigFlow(ConfigFlow, domain=DOMAIN):

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        if user_input is not None:
            return self.async_create_entry(title=DEFAULT_NAME, data=user_input)

        return self.async_show_form(step_id="user", data_schema=self.add_suggested_values_to_schema(
            vol.Schema(
                {
                    vol.Required(CONF_RADIUS, default=1000): vol.Coerce(float),
                    vol.Required(CONF_LATITUDE): cv.latitude,
                    vol.Required(CONF_LONGITUDE): cv.longitude,
                    vol.Required(CONF_SCAN_INTERVAL, default=20): int,
                }
            ),
            {
                CONF_LATITUDE: self.hass.config.latitude,
                CONF_LONGITUDE: self.hass.config.longitude,
            },
        ))

    @staticmethod
    @callback
    def async_get_options_flow(config_entry: ConfigEntry) -> OptionsFlow:
        return FlightRadarOptionsFlow(config_entry)


class FlightRadarOptionsFlow(OptionsFlowWithConfigEntry):

    async def async_step_init(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        errors = {}
        data = user_input or self.config_entry.data

        if user_input is not None:
            username = data.get(CONF_USERNAME)
            password = data.get(CONF_PASSWORD)

            try:
                if username and password:
                    client = FlightRadar24API()
                    await self.hass.async_add_executor_job(client.login, username, password)
                elif (password and not username) or (username and not password):
                    errors["base"] = "credentials_incomplete"
            except Exception as error:
                if _is_login_rate_limited(error):
                    _LOGGER.warning(
                        "FlightRadar24: login rate-limited while saving options (%s); "
                        "credentials stored, integration will retry login on reload",
                        error,
                    )
                elif _is_login_auth_error(error):
                    _LOGGER.error("FlightRadar24: login rejected - %s", error)
                    errors["base"] = "invalid_auth"
                else:
                    _LOGGER.error("FlightRadar24: login failed - %s", error)
                    errors["base"] = "login_failed"

            if not errors:
                self.hass.config_entries.async_update_entry(self.config_entry, data=user_input)
                return self.async_create_entry(title=DEFAULT_NAME, data=user_input)

        data_schema = vol.Schema({
            vol.Required(CONF_RADIUS, default=data.get(CONF_RADIUS)): vol.Coerce(float),
            vol.Required(CONF_LATITUDE, default=data.get(CONF_LATITUDE)): cv.latitude,
            vol.Required(CONF_LONGITUDE, default=data.get(CONF_LONGITUDE)): cv.longitude,
            vol.Required(CONF_SCAN_INTERVAL, default=data.get(CONF_SCAN_INTERVAL)): int,
            vol.Optional(CONF_MIN_ALTITUDE,
                         description={"suggested_value": data.get(CONF_MIN_ALTITUDE, MIN_ALTITUDE)}): int,
            vol.Optional(CONF_MAX_ALTITUDE,
                         description={"suggested_value": data.get(CONF_MAX_ALTITUDE, MAX_ALTITUDE)}): int,
            vol.Optional(CONF_ENABLE_TRACKER,
                         description={
                             "suggested_value": data.get(CONF_ENABLE_TRACKER,
                                                         CONF_ENABLE_TRACKER_DEFAULT)}): cv.boolean,
            vol.Optional(CONF_AUTO_CLEANUP,
                         description={
                             "suggested_value": data.get(CONF_AUTO_CLEANUP,
                                                         CONF_AUTO_CLEANUP_DEFAULT)}): cv.boolean,
            vol.Optional(
                CONF_TRACKER_NAME_STYLE,
                default=data.get(
                    CONF_TRACKER_NAME_STYLE,
                    CONF_TRACKER_NAME_DEFAULT,
                ),
            ): vol.In(
                {
                    TRACKER_NAME_CALLSIGN: "Callsign Only (e.g., KLM1412)",
                    TRACKER_NAME_CALLSIGN_ROUTE: (
                        "Callsign + Route (e.g., KLM1412 (CDG - AMS))"
                    ),
                    TRACKER_NAME_REG_ROUTE: (
                        "Registration + Route (e.g., PH-BXE (CDG - AMS))"
                    ),
                }
            ),
            vol.Optional(CONF_USERNAME, description={"suggested_value": data.get(CONF_USERNAME, '')}): cv.string,
            vol.Optional(CONF_PASSWORD, description={"suggested_value": data.get(CONF_PASSWORD, '')}): cv.string,
        })

        return self.async_show_form(step_id="init", data_schema=data_schema, errors=errors)
